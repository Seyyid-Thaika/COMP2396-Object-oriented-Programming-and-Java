/**
 * 
 * A class representing a Regular Polygon shape.
 * 
 * The RegularPolygon class is a subclass of the superclass Shape 
 * and represents a regular polygon with a specified 
 * number of sides and radius.
 * 
 * @author Seyyid Thaika
 * 
 */
public class RegularPolygon extends Shape {
	
    /** An integer specifying No. of sides of the polygon. */
    private int numOfSides;
    
    /** A double specifying radius of the polygon. */
    private double radius;

    /**
     * 
     * Constructor to create a RegularPolygon with the specified no. of sides and radius.
     * 
     * @param n Number of sides.
     * @param r Radius of the polygon.
     * 
     */
    public RegularPolygon(int n, double r) {
    	
        super();
        
        setNumOfSides(n);
        
        setRadius(r);
        
        setVertices();
        
    }

    /**
     * 
     * Constructor to create a RegularPolygon with the specified no. of sides. 
     * The default radius is 1.0.
     * 
     * @param n Number of sides.
     * 
     */
    public RegularPolygon(int n) {
    	
        this(n, 1.0);
        
    }

    /**
     * 
     * Creates a RegularPolygon with 3 sides and 1.0 radius.
     * This is a default constructor.
     * 
     */
    public RegularPolygon() {
    	
        this(3, 1.0);
        
    }

    /**
     * 
     * Returns the no. of sides of the polygon.
     * 
     * @return Number of sides.
     * 
     */
    public int getNumOfSides() {
    	
        return numOfSides;
        
    }

    /**
     * 
     * Returns the radius of the polygon.
     * 
     * @return Radius of the polygon.
     * 
     */
    public double getRadius() {
    	
        return radius;
        
    }

    /**
     * 
     * Sets the no. of sides of the polygon.
     * Min no. of sides is 3.
     * 
     * @param n Number of sides.
     * 
     */
    public void setNumOfSides(int n) {
    	
        numOfSides = (n < 3) ? 3 : n;
        
        setVertices();
        
    }

    /**
     * 
     * Sets the radius of the polygon. If the provided value is negative, the radius is set to 0.
     * 
     * @param r Radius of the polygon.
     * 
     */
    public void setRadius(double r) {
    	
        radius = (r < 0) ? 0 : r;
        
        setVertices();
        
    }

    /**
     * Private helper method to set the vertices of the polygon based on its sides and radius.
     */
    private void setVertices() {
    	
        double[] xLocal = new double[numOfSides];
        
        double[] yLocal = new double[numOfSides];

        for (int i = 0; i < numOfSides; i++) {
        	
            if (numOfSides % 2 == 0) {
            	
                xLocal[i] = radius * Math.cos(Math.PI / numOfSides + 2 * Math.PI / numOfSides * i);
                
                yLocal[i] = radius * Math.sin(Math.PI / numOfSides + 2 * Math.PI / numOfSides * i);
                
            } else {
            	
                xLocal[i] = radius * Math.cos(2 * Math.PI / numOfSides * i);
                
                yLocal[i] = radius * Math.sin(2 * Math.PI / numOfSides * i);
                
            }
            
        }

        setXLocal(xLocal);
        
        setYLocal(yLocal);
        
    }

    /**
     * 
     * Checks if the specified point (x,y) lies inside the polygon.
     * 
     * @param x X-coordinate of the point.
     * @param y Y-coordinate of the point.
     * @return True if the point is inside the polygon, false otherwise.
     * 
     */
    public boolean contains(double x, double y) {
    	
        double Xcor = (x - getXc()) * Math.cos(-getTheta()) - (y - getYc()) * Math.sin(-getTheta());
        
        double Ycor = (x - getXc()) * Math.sin(-getTheta()) + (y - getYc()) * Math.cos(-getTheta());
        
        double[] xLocal = getXLocal();

        double angle = 2 * Math.PI / numOfSides;
        
        double verticalside = xLocal[numOfSides / 2];

        for (int i = 0; i < numOfSides; i++) {
        	
            double rotate =  Math.cos(angle * i)*Xcor - Math.sin(angle * i)*Ycor;
            
            if (rotate < verticalside) {
            	
                return false;
                
            }
            
        }
        
        return true;
        
    }
    
}

