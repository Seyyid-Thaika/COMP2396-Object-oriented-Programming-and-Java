/**
 * 
 * A class representing generic geometric shape with rotation and translation capabilities.
 * 
 * The Shape class provides basic functions for manipulating 
 * geometric shapes such as rotation, translation, and attribution.
 * 
 * @author Seyyid Thaika
 * 
 */
public class Shape {
    
    /** The color of the shape. */
    private java.awt.Color color;
    
    /** A boolean specifying whether the shape is filled or not. */
    private boolean filled;
    
    /** The orientation of the shape in radians in the canvas coordinate system. */
    private double theta;
    
    /** The x-coordinate of the shape's center. */
    private double xc;
    
    /** The y-coordinate of the shape's center. */
    private double yc;
    
    /** The local x-coordinates of the shape's vertices. */
    private double[] xLocal;
    
    /** The local y-coordinates of the shape's vertices. */
    private double[] yLocal;
    
    /**
     * Default constructor that initializes an empty shape.
     */
    public Shape() {
    }

    /**
     * 
     * Constructs a shape with the specified attributes.
     * 
     * @param color    The color of the shape.
     * @param filled   Boolean specifying whether the shape is filled.
     * @param theta    The orientation of the shape.
     * @param xc       The x-coordinate of the shape's center.
     * @param yc       The y-coordinate of the shape's center.
     * @param xLocal   The local x-coordinates of the shape's vertices.
     * @param yLocal   The local y-coordinates of the shape's vertices.
     * 
     */
    public Shape(java.awt.Color color, boolean filled, double theta, double xc, double yc, double[] xLocal, double[] yLocal) {
    	
        this.color = color;
        
        this.filled = filled;
        
        this.theta = theta;
        
        this.xc = xc;
        
        this.yc = yc;
        
        this.xLocal = xLocal;
        
        this.yLocal = yLocal;
        
    }

    /**
     * 
     * Returns the color of the shape.
     * 
     * @return Color of the shape.
     * 
     */
    public java.awt.Color getColor() {
        return color;
    }

    /**
     * 
     * Specifies whether the shape is filled or not.
     * 
     * @return True if the shape is filled, false otherwise.
     * 
     */
    public boolean getFilled() {
        return filled;
    }

    /**
     * 
     * Returns the orientation of the shape.
     * 
     * @return orientation of the shape in radians.
     * 
     */
    public double getTheta() {
        return theta;
    }

    /**
     * 
     * Returns the x-coordinate of the shape's center.
     * 
     * @return X-coordinate of the shape's center.
     * 
     */
    public double getXc() {
        return xc;
    }

    /**
     * 
     * Returns the y-coordinate of the shape's center.
     * 
     * @return Y-coordinate of the shape's center.
     * 
     */
    public double getYc() {
        return yc;
    }

    /**
     * 
     * Returns the local x-coordinates of the shape's vertices.
     * 
     * @return Array of local x-coordinates of the shape's vertices.
     * 
     */
    public double[] getXLocal() {
        return xLocal;
    }

    /**
     * 
     * Returns the local y-coordinates of the shape's vertices.
     * 
     * @return Array of local y-coordinates of the shape's vertices.
     * 
     */
    public double[] getYLocal() {
        return yLocal;
    }

    /**
     * 
     * Sets the color of the shape.
     * 
     * @param color New color for the shape.
     * 
     */
    public void setColor(java.awt.Color color) {
        this.color = color;
    }

    /**
     * 
     * Sets the filled attribute of the shape.
     * 
     * @param filled True to fill the shape, false otherwise.
     * 
     */
    public void setFilled(boolean filled) {
        this.filled = filled;
    }

    /**
     * 
     * Sets the rotation angle of the shape.
     * 
     * @param theta New rotation angle in radians.
     * 
     */
    public void setTheta(double theta) {
        this.theta = theta;
    }

    /**
     * 
     * Sets the x-coordinate of the shape's center.
     * 
     * @param xc New x-coordinate for the shape's center.
     * 
     */
    public void setXc(double xc) {
        this.xc = xc;
    }

    /**
     * 
     * Sets the y-coordinate of the shape's center.
     * 
     * @param yc New y-coordinate for the shape's center.
     * 
     */
    public void setYc(double yc) {
        this.yc = yc;
    }

    /**
     * 
     * Sets the local x-coordinates of the shape's vertices.
     * 
     * @param xLocal Array of new local x-coordinates for the shape's vertices.
     * 
     */
    public void setXLocal(double[] xLocal) {
        this.xLocal = xLocal;
    }

    /**
     * 
     * Sets the local y-coordinates of the shape's vertices.
     * 
     * @param yLocal Array of new local y-coordinates for the shape's vertices.
     * 
     */
    public void setYLocal(double[] yLocal) {
        this.yLocal = yLocal;
    }

    /**
     * 
     * Translates the shape by the specified deltas.
     * 
     * @param dx Delta in the x-direction.
     * @param dy Delta in the y-direction.
     * 
     */
    public void translate(double dx, double dy) {
        this.xc += dx;
        this.yc += dy;
    }

    /**
     * 
     * Rotates the shape by the specified angle.
     * 
     * @param dt Angle in radians to rotate the shape.
     * 
     */
    public void rotate(double dt) {
        this.theta += dt;
    }

    /**
     * 
     * Returns the computed x-coordinates of the shape's vertices based on its current position and rotation.
     * 
     * @return Array of computed x-coordinates.
     * 
     */
    public int[] getX() {
    	
        int[] canvas_x = new int[xLocal.length];
        
        for (int a = 0; a < xLocal.length; a++) {
        	
            canvas_x[a] = (int) Math.round(xLocal[a] * Math.cos(theta) - yLocal[a] * Math.sin(theta) + xc);
            
        }
        
        return canvas_x;
        
    }

    /**
     * 
     * Retrieves the computed y-coordinates of the shape's vertices based on its current position and rotation.
     * 
     * @return Array of computed y-coordinates.
     * 
     */
    public int[] getY() {
    	
        int[] canvas_y = new int[yLocal.length];
        
        for (int b = 0; b < yLocal.length; b++) {
        	
            canvas_y[b] = (int) Math.round(xLocal[b] * Math.sin(theta) + yLocal[b] * Math.cos(theta) + yc);
            
        }
        
        return canvas_y;
        
    }
    
}
