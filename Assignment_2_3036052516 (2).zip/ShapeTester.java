public class ShapeTester {
	
    public static void main(String[] args) {
    	
        // Creating a shape with default constructor
    	
        Shape shape_a = new Shape();
        
        // Printing default values
        
        System.out.println("Default Values of Shape A:");
        
        System.out.println("Color: " + shape_a.getColor());
        
        System.out.println("Filled: " + shape_a.getFilled());
        
        System.out.println("Theta: " + shape_a.getTheta());
        
        System.out.println("Xc: " + shape_a.getXc());
        
        System.out.println("Yc: " + shape_a.getYc());
        
        System.out.println();
        
        // Creating a shape with parameterized constructor
        
        double[] xLocal = {1.0, 2.0, 3.0};
        
        double[] yLocal = {1.0, 2.0, 3.0};
        
        Shape shape_b = new Shape(java.awt.Color.RED, true, Math.PI / 4, 2.0, 2.0, xLocal, yLocal);
        
        // Printing values of shape_b
        
        System.out.println("Values of Shape B:");
        
        System.out.println("Color: " + shape_b.getColor());
        
        System.out.println("Filled: " + shape_b.getFilled());
        
        System.out.println("Theta: " + shape_b.getTheta());
        
        System.out.println("Xc: " + shape_b.getXc());
        
        System.out.println("Yc: " + shape_b.getYc());
        
        System.out.println();
        
        // Altering properties of shape_b
        
        shape_b.translate(1.0, -1.0);
        
        shape_b.rotate(Math.PI / 4);
        
        // Printing updated values of shape_b
        
        System.out.println("Updated Values of Shape B:");
        
        System.out.println("Theta: " + shape_b.getTheta());
        
        System.out.println("Xc: " + shape_b.getXc());
        
        System.out.println("Yc: " + shape_b.getYc());
        
        System.out.println("Canvas X: " + java.util.Arrays.toString(shape_b.getX()));
        
        System.out.println("Canvas Y: " + java.util.Arrays.toString(shape_b.getY()));
        
        System.out.println();
        
    }
    
}
