public class RegularPolygonTester {
	
    public static void main(String[] args) {
    	
        // Creating a RegularPolygon with default constructor
    	
        RegularPolygon polygon_a = new RegularPolygon();
        
        // Printing default values
        
        System.out.println("Default Values of Polygon A:");
        
        System.out.println("No. of Sides: " + polygon_a.getNumOfSides());
        
        System.out.println("Radius: " + polygon_a.getRadius());
        
        // Checking if a point is in the polygon
        
        System.out.println("Contains (0,0): " + polygon_a.contains(0, 0));
        
        // Creating a RegularPolygon with specific number of radius and sides
        
        RegularPolygon polygon_b = new RegularPolygon(6, 2.0);
        
        // Printing values of polygon_b
        
        System.out.println();
        
        System.out.println("Values of Polygon B:");
        
        System.out.println("No. of Sides: " + polygon_b.getNumOfSides());
        
        System.out.println("Radius: " + polygon_b.getRadius());
        
        // Checking if a point is in the polygon
        
        System.out.println("Contains (1,1): " + polygon_b.contains(1, 1));
        
        System.out.println("Contains (2,2): " + polygon_b.contains(2, 2));
        
        System.out.println();
        
        // Updating properties of polygon_b
        
        polygon_b.setNumOfSides(5);
        
        polygon_b.setRadius(3.0);
        
        // Printing updated values of polygon_b
        
        System.out.println("Updated Values of Polygon B:");
        
        System.out.println("No. of Sides: " + polygon_b.getNumOfSides());
        
        System.out.println("Radius: " + polygon_b.getRadius());
        
    }
    
}
