/**
 * Represents a hand of cards in the Big Two card game that forms a triple (three-of-a-kind).
 * A triple consists of three cards with the same rank.
 * 
 * @author Seyyid Thaika
 */
public class Triple extends Hand {
    /**
     * Constructs a Triple hand with the specified player and cards.
     * 
     * @param player The player who played this hand.
     * @param cards  The list of cards forming the triple.
     */
    public Triple(CardGamePlayer player, CardList cards) {
        super(player, cards);
    }

    /**
     * Checks if this hand is a valid triple.
     * 
     * @return `true` if the hand is a valid triple, `false` otherwise.
     */
    public boolean isValid() {		// Checks if Valid
        boolean check = true;	// Valid
        if (this.size() == 3) {
            for (int x = 0; x < 2; x++) {		// Checks suits
                if (this.getCard(x).getRank() != this.getCard(x + 1).getRank()) {
                    check = false;		// Not Valid
                }
            }
        } else {
            check = false;	// Not Valid
        }

        return check;		// Valid
    }

    /**
     * Gets the type of this hand (which is "Triple").
     * 
     * @return The type of this hand.
     */
    public String getType() {
        return "Triple";
    }
}
