import java.util.ArrayList;
/**
 * A class that represents a game of Big Two.
 *
 * @author Seyyid Thaika
 */
public class BigTwo implements CardGame {
    /** The number of players in the game. */
    private int numOfPlayers;

    /** The deck of cards used in the game. */
    private Deck deck;

    /** The list of players in the game. */
    private ArrayList<CardGamePlayer> playerList;

    /** The list of hands on the table. */
    private ArrayList<Hand> handsOnTable;

    /** The index of the current player. */
    private int currentPlayerIdx;

    /** The user interface for the game. */
    private BigTwoUI ui;

    /**
     * Creates a new instance of the `BigTwo` class.
     */
    public BigTwo() {
        numOfPlayers = 4;
        deck = new Deck();
        playerList = new ArrayList<>();
        handsOnTable = new ArrayList<>();
        ui = new BigTwoUI(this);
        for (int i = 0; i < 4; i++) {
            playerList.add(new CardGamePlayer());
        }
    }

    /**
     * Returns the number of players in the game.
     *
     * @return the number of players in the game
     */
    public int getNumOfPlayers() {
        return this.numOfPlayers;
    }

    /**
     * Returns the deck of cards used in the game.
     *
     * @return the deck of cards used in the game
     */
    public Deck getDeck() {
        return this.deck;
    }

    /**
     * Returns the list of players in the game.
     *
     * @return the list of players in the game
     */
    public ArrayList<CardGamePlayer> getPlayerList() {
        return this.playerList;
    }

    /**
     * Returns the list of hands on the table.
     *
     * @return the list of hands on the table
     */
    public ArrayList<Hand> getHandsOnTable() {
        return this.handsOnTable;
    }

    /**
     * Returns the index of the current player.
     *
     * @return the index of the current player
     */
    public int getCurrentPlayerIdx() {
        return this.currentPlayerIdx;
    }

    /**
     * Starts the game with the given deck.
     *
     * @param deck the deck to use for the game
     */
    public void start(Deck deck) {
    	// Removes all cards
        for (int x = 0; x < playerList.size(); x++) {
            playerList.get(x).removeAllCards();
        }
        handsOnTable.clear();

        // Distributes cards
        for (int y = 0; y < 52; y++) {
            playerList.get(y % 4).addCard(deck.getCard(y));
        }
        
        // Sorts cards
        for (int z = 0; z < 4; z++) {
            playerList.get(z).getCardsInHand().sort();
        }

        // Identifies cards
        BigTwoCard threeOfDiamonds = new BigTwoCard(0, 2);
        for (int a = 0; a < numOfPlayers; a++) {
            if (playerList.get(a).getCardsInHand().contains(threeOfDiamonds)) {
                currentPlayerIdx = a;
                ui.setActivePlayer(a);
                break;
            }
        }
        ui.repaint();		// Repaints
        ui.promptActivePlayer();	// Calls active players
    }

    /**
     * Makes a move for the specified player.
     *
     * @param playerIdx the index of the player making the move
     * @param cardIdx the index of the card being played
     */
    public void makeMove(int playerIdx, int[] cardIdx) {
        checkMove(playerIdx, cardIdx);
    }

    /**
     * Checks whether the specified move is valid.
     *
     * @param playerIdx the index of the player making the move
     * @param cardIdx the index of the card being played
     * @return true if the move is valid, false otherwise
     */
	public void checkMove(int playerIdx, int[] cardIdx) {

		BigTwoCard threeOfDiamond = new BigTwoCard(0,2);
		this.currentPlayerIdx = playerIdx;
		// if move is allowed
		boolean allowedMove = false; 

		// No hand previously
		if (this.handsOnTable.isEmpty()) {  
			CardList cards = new CardList();
			if (cardIdx != null) {
				for (int b = 0; b < cardIdx.length; b++) {
					cards.addCard(this.getPlayerList().get(playerIdx).getCardsInHand().getCard(cardIdx[b]));
				}
			}
			
			// When Player doesn't pass
			if (!cards.isEmpty()) {  
				Hand hand = composeHand(playerList.get(currentPlayerIdx) , cards);
				
				// Hand is allowed
				if (hand != null) { 
					
					if (!hand.contains(threeOfDiamond)) {
						ui.printMsg("Not a legal move!!!\n");
						ui.promptActivePlayer();
							
					}
					
					// Hand contains Three of Diamonds
					else {
						ui.printMsg("{" + hand.getType() + "}" + " ");
						ui.printMsg(hand.toString());
						ui.printMsg("\n");
						ui.printMsg("\n");
						this.handsOnTable.add(hand);
						
						for (int c = 0; c < hand.size(); c++) {
							playerList.get(currentPlayerIdx).getCardsInHand().removeCard(hand.getCard(c));
						}
						allowedMove = true;
					
					}
						
				}
				
				//if hand isn't valid
				else {	
					System.out.println("Not a legal move!!!");
					ui.promptActivePlayer();
				}
						
			}
			// If hand is empty
			else {	
				System.out.println("Not a legal move!!!\n");
				ui.promptActivePlayer();
				
			}
	
		}
		
		else { 
				
				CardList cards = new CardList();
				if (cardIdx != null) {
					for (int x = 0; x < cardIdx.length; x++) {
						cards.addCard(this.getPlayerList().get(playerIdx).getCardsInHand().getCard(cardIdx[x]));
					}
				}
				
				
				// Player has to hand since other's passed
				if (!cards.isEmpty()) {
					Hand hand = composeHand(playerList.get(currentPlayerIdx) , cards);
					
					if (hand != null && (this.playerList.get(currentPlayerIdx).getName() == this.getHandsOnTable().get(this.getHandsOnTable().size()-1).getPlayer().getName())) {  
						this.handsOnTable.add(hand);
						ui.printMsg("<" + playerList.get(currentPlayerIdx).getName() + ">" + " " + hand.getType() + " ");
						ui.printMsg(hand.toString());
						ui.printMsg("\n");
		
						for (int y = 0; y < hand.size(); y++) {
							playerList.get(currentPlayerIdx).getCardsInHand().removeCard(hand.getCard(y));
						}
						allowedMove = true;
					}
					
					
					// if previous hand is bet
					else if (hand != null && hand.beats(handsOnTable.get(handsOnTable.size()-1))) {  
						this.handsOnTable.add(hand);
						ui.printMsg("<" + playerList.get(currentPlayerIdx).getName() + ">" + " " + hand.getType() + " ");
						ui.printMsg(hand.toString());
						ui.printMsg("\n");
						
						for (int z = 0; z < hand.size(); z++) {
							playerList.get(currentPlayerIdx).getCardsInHand().removeCard(hand.getCard(z));
						}
						allowedMove = true;
						ui.printMsg("\n");
					}
						
					// if previous hand isn't bet
					else {
						ui.printMsg("Not a legal move!!!\n");
						ui.printMsg("\n");
						ui.promptActivePlayer();
						
					}
				}
					
				else if (this.playerList.get(currentPlayerIdx).getName() == this.getHandsOnTable().get(this.getHandsOnTable().size()-1).getPlayer().getName())  { 
					ui.printMsg("Not a legal move!!!\n");
					ui.printMsg("\n");
					ui.promptActivePlayer();
				}
				
				else {
					ui.printMsg("{Pass}\n");
					ui.printMsg("\n");
					allowedMove = true;
					
				}
		}
		
		// if game has ended
		if (this.endOfGame()) {
			ui.printMsg("\n");
			ui.setActivePlayer(-1);
			ui.repaint();
			
			System.out.println();
			ui.printMsg("Game ends\n");
			for (int a = 0; a < 4; a++) {
				if (a == currentPlayerIdx) {
					ui.printMsg(String.format("Player %d wins the game.\n", a));
				}
				else {
					int numOfCards = playerList.get(a).getCardsInHand().size();
					ui.printMsg(String.format("Player %d has %d cards in hand.\n", a, numOfCards));
				}
			}	
			System.exit(0);
		}
	
		else if (allowedMove == true){
			this.currentPlayerIdx = (playerIdx + 1) % 4; 
			ui.setActivePlayer(this.currentPlayerIdx);
		}
		else
			ui.repaint();
		
		ui.repaint();		// repaints
		ui.promptActivePlayer();	// Calls Active Players
	
	}
	
	 /**
     * Checks whether the game has ended.
     * @return true if the game has ended, false otherwise
     */
	public boolean endOfGame() {
		for (int b = 0; b < numOfPlayers; b++) {
        	if (playerList.get(b).getCardsInHand().size() == 0) {
        		return true;
        	}
		}
		return false;
	}
	
	 /**
     * Main method for testing the BigTwo class.
     * @param args command line arguments
     */
	public static void main(String[] args) {
		BigTwo newGame = new BigTwo();				//Create a new game
		BigTwoDeck newDeck = new BigTwoDeck();		//Create a deck
		newDeck.initialize();
		newDeck.shuffle();
		newGame.start(newDeck);
		
	}

	
	/**
     * Composes a hand of cards from the given player and cards.
     * @param player the player who is composing the hand
     * @param cards the cards that make up the hand
     * @return the composed hand
     */
	 public static Hand composeHand(CardGamePlayer player, CardList cards) {
		 Hand hand;		//Create a hand
		 
		// When size is 1
		 if (cards.size() == 1) {
			 hand = new Single(player, cards);
			 if (hand.isValid()) {
				 return hand;
			 }
		 }
		 
		// When size is 2
		 else if (cards.size() == 2) {
			 hand = new Pair(player, cards);
			 if (hand.isValid()) {
				 return hand;
			 }
		 }
		 
		 // When size is 3
		 else if (cards.size() == 3) {
			 hand = new Triple(player, cards);
			 if (hand.isValid()) {
				 return hand;
			 }
		 }
		 
		 // Sorts by Ranking
		 else if (cards.size() == 5) {
			 hand = new StraightFlush(player, cards);
			 if (hand.isValid()) {
				 return hand;
			 }
			 hand = new Quad(player, cards);
			 if (hand.isValid()) {
				 return hand;
			 }
			 hand = new FullHouse(player, cards);
			 if (hand.isValid()) {
				 return hand;
			 }
			 hand = new Flush(player, cards);
			 if (hand.isValid()) {
				 return hand;
			 }
			 hand = new Straight(player, cards);
			 if (hand.isValid()) {
				 return hand;
			 }
			 
		 }
		 // Game Ends
		 return null;
	 }
}
