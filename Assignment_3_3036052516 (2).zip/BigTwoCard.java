/**
 * Represents a card in the Big Two card game.
 * 
 * @author Seyyid Thaika
 */
public class BigTwoCard extends Card {
    /**
     * Constructs a BigTwoCard with the specified suit and rank.
     * 
     * @param s The suit of the card (0 to 3, representing hearts, diamonds, clubs, and spades).
     * @param r The rank of the card (0 to 12, representing 2 to Ace).
     */
    public BigTwoCard(int s, int r) {
        super(s, r);
    }

    /**
     * Compares this card to another card.
     * 
     * @param c The card to compare to.
     * @return A positive integer if this card is greater, a negative integer if this card is smaller,
     *         or 0 if the cards are equal.
     */
    
    // Comparing rank and target of card
    public int compareTo(Card c) {
        int rankOfCard = this.getRank();
        int aimOfRank = c.getRank();
        
        if (rankOfCard == 0 || rankOfCard == 1) {
            rankOfCard += 13;
        }
        if (aimOfRank == 0 || aimOfRank == 1) {
            aimOfRank += 13;
        }
        
        // Positive is greater
        if (rankOfCard > aimOfRank) {
            return 1;
        } else if (rankOfCard < aimOfRank) {  // Negative if smaller
            return -1;
        } else if (this.getSuit() > c.getSuit()) {
            return 1;
        } else if (this.getSuit() < c.getSuit()) {
            return -1;
        } else {
            return 0;
        }
    }
}
