/**
 * Represents a hand of cards in the Big Two card game that forms a quad (four-of-a-kind).
 * A quad consists of four cards with the same rank.
 * 
 * @author Seyyid Thaika
 */
public class Quad extends Hand {
    private int num = 3; // No. of cards

    /**
     * Constructs a Quad hand with the specified player and cards.
     * 
     * @param player The player who played this hand.
     * @param cards  The list of cards forming the quad.
     */
    public Quad(CardGamePlayer player, CardList cards) {
        super(player, cards);
    }

    /**
     * Gets the value associated with this quad.
     * 
     * @return The value of this quad.
     */
    public int getValue() {
        return this.num;	// Gets no. of cards
    }

    /**
     * Checks if this hand is a valid quad.
     * 
     * @return `true` if the hand is a valid quad, `false` otherwise.
     */
    public boolean isValid() {
        this.sort();
        boolean check = true;		// Valid

        if (this.size() == 5) {
            if (this.getCard(0).getRank() == this.getCard(1).getRank()) {
                for (int x = 0; x < 3; x++) {
                    if (this.getCard(x).getRank() != this.getCard(x + 1).getRank()) {
                        check = false;	// Not Valid
                    }
                }
            } else if (this.getCard(4).getRank() == this.getCard(3).getRank()) {
                for (int y = 1; y < 4; y++) {
                    if (this.getCard(y).getRank() != this.getCard(y + 1).getRank()) {
                        check = false;		// Not Valid
                    }
                }
            } else {
                check = false;		// Not Valid
            }
        } else {
            check = false;		// Not Valid
        }

        return check;	// Valid
    }

    /**
     * Gets the type of this hand (which is "Quad").
     * 
     * @return The type of this hand.
     */
    public String getType() {
        return "Quad";
    }
}

