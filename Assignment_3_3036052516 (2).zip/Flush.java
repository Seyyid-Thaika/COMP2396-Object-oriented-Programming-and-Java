/**
 * Represents a hand of cards in the Big Two card game that forms a flush.
 * A flush consists of five cards of the same suit.
 * 
 * @author Seyyid Thaika
 */
public class Flush extends Hand {
    private int num = 1; // no. of cards

    /**
     * Constructs a Flush hand with the specified player and cards.
     * 
     * @param player The player who played this hand.
     * @param cards  The list of cards forming the flush.
     */
    public Flush(CardGamePlayer player, CardList cards) {
        super(player, cards);
    }

    /**
     * Gets the value associated with this flush.
     * 
     * @return The value of this flush.
     */
    public int getValue() {
        return this.num;
    }

    /**
     * Checks if this hand is a valid flush.
     * 
     * @return `true` if the hand is a valid flush, `false` otherwise.
     */
    public boolean isValid() {
        this.sort();
        boolean check = true;	

        if (this.size() == 5) {	// Checks if it's a valid move
            for (int x = 0; x < 4; x++) {	// Searches suits from 0 to 3.
                if (this.getCard(x).getSuit() != this.getCard(x + 1).getSuit()) {
                    check = false;
                }
            }
        } else {
            check = false;		// Not Valid
        }

        return check;		// Valid
    }

    /**
     * Gets the type of this hand (which is "Flush").
     * 
     * @return The type of this hand.
     */
    public String getType() {
        return "Flush";
    }
}
