/**
 * Represents a hand of cards in the Big Two card game that consists of a single card.
 * A single hand contains only one card.
 * 
 * @author Seyyid Thaika
 */
public class Single extends Hand {
    /**
     * Constructs a Single hand with the specified player and cards.
     * 
     * @param player The player who played this hand.
     * @param cards  The list of cards forming the single hand (should contain only one card).
     */
    public Single(CardGamePlayer player, CardList cards) {
        super(player, cards);
    }

    /**
     * Checks if this hand is a valid single hand (contains exactly one card).
     * 
     * @return `true` if the hand is a valid single hand, `false` otherwise.
     */
    public boolean isValid() {
        if (this.size() == 1) {
            return true;		// Valid
        } else {
            return false;		// Not Valid
        }
    }

    /**
     * Gets the type of this hand (which is "Single").
     * 
     * @return The type of this hand.
     */
    public String getType() {
        return "Single";
    }
}
