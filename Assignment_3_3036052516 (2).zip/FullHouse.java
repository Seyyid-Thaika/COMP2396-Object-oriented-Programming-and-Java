/**
 * Represents a hand of cards in the Big Two card game that forms a full house.
 * A full house consists of three cards of one rank and two cards of another rank.
 * 
 * @author Seyyid Thaika
 */
public class FullHouse extends Hand {
    private int num = 2; // no. of cards

    /**
     * Constructs a FullHouse hand with the specified player and cards.
     * 
     * @param player The player who played this hand.
     * @param cards  The list of cards forming the full house.
     */
    public FullHouse(CardGamePlayer player, CardList cards) {
        super(player, cards);
    }

    /**
     * Gets the value associated with this full house.
     * 
     * @return The value of this full house.
     */
    public int getValue() {
        return this.num;
    }

    /**
     * Checks if this hand is a valid full house.
     * 
     * @return `true` if the hand is a valid full house, `false` otherwise.
     */
    public boolean isValid() {
        this.sort();
        boolean check = true;	// checks if valid
        Card fc = this.getCard(2); // Middle card (assumed to be the three-of-a-kind card)

        if (this.size() == 5) {
            if (this.getCard(1).getRank() == fc.getRank()) {
                if (this.getCard(0).getRank() != this.getCard(1).getRank()) {
                    check = false;		// Not Valid
                }
                if (this.getCard(3).getRank() != this.getCard(4).getRank()) {
                    check = false;		// Not Valid
                }
            } else if (this.getCard(3).getRank() == fc.getRank()) {
                if (this.getCard(3).getRank() != this.getCard(4).getRank()) {
                    check = false;		// Not Valid
                }
                if (this.getCard(0).getRank() != this.getCard(1).getRank()) {
                    check = false;
                }
            } else {
                check = false;		// Not Valid
            }
        } else {
            check = false;		// Not Valid
        }

        return check;	// Valid
    }

    /**
     * Gets the type of this hand (which is "FullHouse").
     * 
     * @return The type of this hand.
     */
    public String getType() {
        return "FullHouse";
    }
}
