/**
 * Represents a hand of cards in the Big Two card game that forms a straight.
 * A straight consists of five consecutive cards (e.g., 3-4-5-6-7).
 * Aces (rank 1) can be considered as both the highest and lowest cards in a straight.
 * 
 * @author Seyyid Thaika
 */
public class Straight extends Hand {
    private int num = 0; // No. of cards

    /**
     * Constructs a Straight hand with the specified player and cards.
     * 
     * @param player The player who played this hand.
     * @param cards  The list of cards forming the straight.
     */
    public Straight(CardGamePlayer player, CardList cards) {
        super(player, cards);
    }

    /**
     * Gets the value associated with this straight.
     * 
     * @return The value of this straight.
     */
    public int getValue() {
        return this.num;	// Gets no. of cards
    }

    /**
     * Checks if this hand is a valid straight.
     * 
     * @return `true` if the hand is a valid straight, `false` otherwise.
     */
    public boolean isValid() {		// Checks if valid
        this.sort();
        boolean check = true;		// Valid

        if (this.size() == 5) {
            for (int x = 0; x < 4; x++) {	// Checks suits from 0-3
                int present = this.getCard(x).getRank();
                int progress = this.getCard(x + 1).getRank();

                if (present == 1 || present == 0) {	
                    present += 13;
                }
                if (progress == 1 || progress == 0) {
                    progress += 13;
                }
                if (present != progress - 1) {
                    check = false;	// Not Valid
                }
            }
        } else {
            check = false; 	// Not Valid
        }

        return check;	// Valid
    }

    /**
     * Gets the type of this hand (which is "Straight").
     * 
     * @return The type of this hand.
     */
    public String getType() {
        return "Straight";
    }
}
