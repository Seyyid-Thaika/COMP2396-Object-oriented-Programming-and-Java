/**
 * Represents a hand of cards in the Big Two card game that forms a pair.
 * A pair consists of two cards with the same rank.
 * 
 * @author Seyyid Thaika
 */
public class Pair extends Hand {
    /**
     * Constructs a Pair hand with the specified player and cards.
     * 
     * @param player The player who played this hand.
     * @param cards  The list of cards forming the pair.
     */
    public Pair(CardGamePlayer player, CardList cards) {
        super(player, cards);
    }

    /**
     * Checks if this hand is a valid pair.
     * 
     * @return `true` if the hand is a valid pair, `false` otherwise.
     */
    public boolean isValid() {
        if (this.size() == 2) {
            if (this.getCard(0).getRank() == this.getCard(1).getRank()) {
                return true;		// Valid
            } else {
                return false;		// Not Valid
            }
        } else {
            return false;		// Not Valid
        }
    }

    /**
     * Gets the type of this hand (which is "Pair").
     * 
     * @return The type of this hand.
     */
    public String getType() {
        return "Pair";
    }
}
