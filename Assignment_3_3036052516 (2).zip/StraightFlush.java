/**
 * Represents a hand of cards in the Big Two card game that forms a straight flush.
 * A straight flush consists of five consecutive cards of the same suit.
 * Aces (rank 1) can be considered as both the highest and lowest cards in a straight flush.
 * 
 * @author Seyyid Thaika
 */
public class StraightFlush extends Hand {
    private int num = 4; // No. of cards

    /**
     * Constructs a StraightFlush hand with the specified player and cards.
     * 
     * @param player The player who played this hand.
     * @param cards  The list of cards forming the straight flush.
     */
    public StraightFlush(CardGamePlayer player, CardList cards) {
        super(player, cards);
    }

    /**
     * Gets the value associated with this straight flush.
     * 
     * @return The value of this straight flush.
     */
    public int getValue() {
        return this.num;
    }

    /**
     * Checks if this hand is a valid straight flush.
     * 
     * @return `true` if the hand is a valid straight flush, `false` otherwise.
     */
    public boolean isValid() {		// Checks if Valid
        this.sort();
        boolean check = true;

        if (this.size() == 5) {
            for (int x = 0; x < 4; x++) {	// Searches suits 0-3
                int present = this.getCard(x).getRank();
                int progress = this.getCard(x + 1).getRank();

                if (present == 1 || present == 0) {
                    present += 13;
                }
                if (progress == 1 || progress == 0) {
                    progress += 13;
                }
                if (present != progress - 1 || this.getCard(x).getSuit() != this.getCard(x + 1).getSuit()) {
                    check = false;	// Not Valid
                }
            }
        } else {
            check = false;	// Not Valid
        }

        return check;		// Valid
    }

    /**
     * Gets the type of this hand (which is "StraightFlush").
     * 
     * @return The type of this hand.
     */
    public String getType() {
        return "StraightFlush";
    }
}


