/**
 * Represents a hand of cards in a card game.
 * A hand can be any combination of cards (e.g., flush, full house, etc.).
 * Subclasses must implement the `isValid()` and `getType()` methods.
 * 
 * @author Seyyid Thaika
 */
public abstract class Hand extends CardList {
    private CardGamePlayer player; // The player associated with this hand

    /**
     * Constructs a hand with the specified player and cards.
     * 
     * @param player The player who played this hand.
     * @param cards  The list of cards forming this hand.
     */
    public Hand(CardGamePlayer player, CardList cards) {
        this.removeAllCards();		// Removes all cards
        this.player = player;
        for (int x = 0; x < cards.size(); x++) {
            this.addCard(cards.getCard(x));
        }
    }

    /**
     * Gets the value associated with this hand.
     * 
     * @return The value of this hand.
     */
    public int getValue() {
        return 0; // no.s
    }

    /**
     * Gets the player associated with this hand.
     * 
     * @return The player who played this hand.
     */
    public CardGamePlayer getPlayer() {
        return this.player;		// Returns players
    }

    /**
     * Gets the top card of this hand (based on specific rules for different hand types).
     * 
     * @return The top card of this hand.
     */
    public Card getTopCard() {
        this.sort();		// sorts deck

        if (this.getType().equals("FullHouse")) {		// Is Full House
            if (this.getCard(2).getRank() == this.getCard(1).getRank()) {
                return this.getCard(2);
            } else {
                return this.getCard(4);
            }
        } else if (this.getType().equals("Quad")) {		// Is Quad
            if (this.getCard(0).equals(this.getCard(1))) {
                return this.getCard(3);
            } else {
                return this.getCard(4);
            }
        } else {
            return getCard(size() - 1);
        }
    }

    /**
     * Compares this hand to another hand to determine if it beats the other hand.
     * 
     * @param hand The hand to compare to.
     * @return `true` if this hand beats the other hand, `false` otherwise.
     */
    public boolean beats(Hand hand) {
        if (this.size() == hand.size()) {
            if (this.getValue() > hand.getValue()) {
                return true;	// Hand Beaten
            } else if (this.getValue() == hand.getValue()) {
                int comp = this.getTopCard().compareTo(hand.getTopCard());
                if (comp == 1) {
                    return true;	// Hand Beaten
                } else if (comp == -1) {
                    return false;	// Hand not Beaten
                }
            } else {
                return false;	// Hand not Beaten
            }
        }
        return false;		// Hand not Beaten
    }

    /**
     * Checks if this hand is valid according to specific rules for each hand type.
     * Subclasses must implement this method.
     * 
     * @return `true` if the hand is valid, `false` otherwise.
     */
    public abstract boolean isValid();

    /**
     * Gets the type of this hand (e.g., "Flush", "FullHouse", etc.).
     * Subclasses must implement this method.
     * 
     * @return The type of this hand.
     */
    public abstract String getType();
}

