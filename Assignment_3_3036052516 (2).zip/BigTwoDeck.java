/**
 * Represents a deck of cards for the Big Two card game.
 * The deck is initialized with 52 standard playing cards.
 * 
 * @author Seyyid Thaika
 */
public class BigTwoDeck extends Deck {
    /**
     * Constructs a new BigTwoDeck by initializing it with 52 cards.
     */
    public BigTwoDeck() {
        this.initialize();
    }

    /**
     * Initializes the deck by removing all existing cards and adding 52 new cards.
     */
    public void initialize() {
        this.removeAllCards();
        for (int suit = 0; suit < 4; suit++) {  // Each card is created with a suit (0 to 3) 
            for (int rank = 0; rank < 13; rank++) {	// and a rank (0 to 12).
                BigTwoCard card = new BigTwoCard(suit, rank);
                this.addCard(card);
            }
        }
    }
}
