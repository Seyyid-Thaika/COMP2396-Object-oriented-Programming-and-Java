import java.awt.Color;

/**
 * 
 * The Shape class is the superclass that represents shapes with color, fill, position, orientation, and vertices.
 * It also provides methods to set vertices, rotate, translate, and retrieve the coordinates of the shape.
 * 
 * @author Seyyid Thaika
 * 
 */

public class Shape {
	
	/**
	 *
	 * a Color object specifying the color of the shape.
	 * 
	 */
    
	public Color color;
    
	/**
     * 
     * a boolean value specifying whether the shape is filled or not filled.
     * 
     */
    
	public boolean filled;      
    
	/**
     * 
     * a double value specifying the orientation (in radians) of the shape 
     * (with respect to its center) in the canvas coordinate system.
     * 
     */
    
	public double theta;  
    
	/**
     * 
     * a double value specifying the x-coordinate of the center 
     * of the shape in the canvas coordinate system.
     * 
     */
    
	public double xc;       
    
	/**
     * 
     * a double value specifying the y-coordinate of the center 
     * of the shape in the canvas coordinate system.
     * 
     */
    
	public double yc;            
    
	/*
     * 
     * an array of double values specifying the x-coordinates of the
     * vertices (in counter-clockwise order) of the shape in its local coordinate system.
     * 
     */
    
    public double[] xLocal;     
    
    /**
     * 
     * an array of double values specifying the y-coordinates of the
     * vertices (in counter- clockwise order) of the shape in its local coordinate system.
     * 
     */
    
    public double[] yLocal;

    /**
     * 
     * a method for setting the local coordinates of the
     * vertices of a shape.
     *
     * @param d  determines shape's vertices. This parameter depends on the
     *           specific shape and its implementation.
     *           
     */
    
    public void setVertices(double d) {
    }

    /**
     * 
     * a method for translating the center of the
     * shape by dx and dy, respectively, along 
     * the x and y directions of the canvas coordinate system.	
     *
     * @param dx to translate in the x direction.
     * 
     * @param dy to translate in the y direction.
     * 
     */

    public void translate(double dx, double dy) {
    	
        xc += dx;
        
        yc += dy;
        
    }

    /**
     * 
     * a method for rotating the shape about its center by an angle
     * of dt (in radians) 
     *
     * @param dt Indicates the angle in radians to rotate the shape.
     * 
     */
    
    public void rotate(double dt) {
    	
        theta += dt;
        
    }

    /**
     * 
     * a method for retrieving the x-coordinates of the vertices 
     * (in counterclockwise order) of the shape in the canvas coordinate system 
     *
     * @return array of integers that represents the x-coordinates of the vertices of the shape.
     * 
     */
    
    public int[] getX() {
    	
        int[] can_x = new int[xLocal.length];
    
        for (int a = 0; a < xLocal.length; a++) {
        	
            double x = xLocal[a] * Math.cos(theta) - yLocal[a] * Math.sin(theta) + xc;
            
            can_x[a] = (int) Math.round(x);
            
        }
       
        return can_x;
        
    }

    /**
     * 
     * a method for retrieving the y-coordinates of the vertices 
     * (in counterclockwise order) of the shape in the canvas coordinate system.
     *
     * @return array of integers that represents the y-coordinates of the vertices of the shape.
     * 
     */
    
    public int[] getY() {
    	
        int[] can_y = new int[yLocal.length];
    
        for (int b = 0; b < yLocal.length; b++) {
        	
            double y = xLocal[b] * Math.sin(theta) + yLocal[b] * Math.cos(theta) + yc;
            
            can_y[b] = (int) Math.round(y);
            
        }
        
        return can_y;
        
    }
}