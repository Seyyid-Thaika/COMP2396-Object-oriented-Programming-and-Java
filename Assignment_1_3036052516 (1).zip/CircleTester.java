public class CircleTester {
	
    public static void main(String[] args) {
    	
        Circle circle = new Circle();
        
        circle.setVertices(5.0); // Set the vertices with radius as 5.0

        // Retrieve the canvas coordinates of the circle's bounding box vertices
        int[] can_x = circle.getX();
        
        int[] can_y = circle.getY();

        // Print the canvas coordinates of the circle's bounding box vertices
        System.out.println("Top left vertices: (" + can_x[0] + ", " + can_y[0] + ")");
        
        System.out.println("Bottown right vertices: (" + can_x[1] + ", " + can_y[1] + ")");
    }
}