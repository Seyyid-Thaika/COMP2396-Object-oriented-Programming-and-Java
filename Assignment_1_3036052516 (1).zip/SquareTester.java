public class SquareTester {
	
    public static void main(String[] args) {
    	
        Square square = new Square();
        
        square.setVertices(1.0); // Set the vertices with half-length of side as 1.0

        // Retrieve the canvas coordinates of the square's vertices
        int[] can_x = square.getX();
        
        int[] can_y = square.getY();

        // Print the canvas coordinates of the square's vertices
        for (int a = 0; a < can_x.length; a++) {
        	
            System.out.println("Vertices " + (a + 1) + ": (" + can_x[a] + ", " + can_y[a] + ")");
        }
    }
}