/**
 * 
 * The Circle class represents a circle shape that is a subclass of the superclass Shape.
 * It inherits the properties and methods from the Shape class and provides
 * a specific implementation for setting the vertices, as well as retrieving
 * the canvas coordinates of the circle's vertices.
 * 
 * @author Seyyid Thaika
 * 
 */

public class Circle extends Shape {

    /**
     * 
     * Sets the vertices of the circle based on given parameters.
     * The vertices are defined in the local coordinate
     * system relative to the center of the circle.
     *
     * @param d value of 'd' determines the size of
     *          the circle and is used to calculate its vertices' coordinates.
     *          
     */
    
	public void setVertices(double d) {
		
        xLocal = new double[] { -d, d };
        
        yLocal = new double[] { -d, d };
        
    }

    /**
     * 
     * a method for retrieving the x-coordinates of the vertices 
     * (in counterclockwise order) of the shape in the canvas coordinate system.
     *
     * @return array of integers representing 
     *         the x-coordinates of the vertices of the circle.
     *         
     */
    
	public int[] getX() {
		
        int[] can_x = new int[2];
        
        for (int a = 0; a < xLocal.length; a++) {
        	
            can_x[a] = (int) Math.round(xLocal[a] + xc);
            
        }
        
        return can_x;
        
    }

    /**
     * 
     * a method for retrieving the y-coordinates of the vertices 
     * (in counterclockwise order) of the shape in the canvas coordinate system. 
     *
     * @return array of integers representing 
     *         the y-coordinates of the vertices of the circle.
     *         
     */
    
	public int[] getY() {
		
        int[] can_y = new int[2];
        
        for (int b = 0; b < yLocal.length; b++) {
        	
            can_y[b] = (int) Math.round(yLocal[b] + yc);
            
        }
        
        return can_y;
        
    }
	
}