/**
 * 
 * The Triangle class represents a triangle shape that is a subclass of the superclass Shape.
 * It inherits the properties and methods from the Shape class and provides
 * a specific implementation for setting the vertices of the triangle.
 * 
 * @author Seyyid Thaika
 * 
 */

public class Triangle extends Shape {

    /**
     * 
     * Sets the vertices of the triangle based on given parameters.
     * The vertices are defined in the local coordinate system 
     * relative to the center of the triangle.
     *
     * @param d value of 'd' determines the size 
     *          of the triangle and is used to calculate its vertices' coordinates.
     *          
     */
	
    public void setVertices(double d) {
    	
        double ang = Math.PI / 3.0;
        
        double cosine_ang = Math.cos(ang);
        
        double sine_ang = Math.sin(ang);

        xLocal = new double[] { d, -d * cosine_ang, -d * cosine_ang };
        
        yLocal = new double[] { 0, -d * sine_ang, d * sine_ang };
        
    }
    
}