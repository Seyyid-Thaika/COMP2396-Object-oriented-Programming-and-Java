public class ShapeTester {
	
    public static void main(String[] args) {
    	
        Square square = new Square();
        
        square.setVertices(5.0); // Set the vertices with half-length of side as 5.0
        
        System.out.println("Square:");
        
        printVertices(square);

        Triangle triangle = new Triangle();
        
        triangle.setVertices(6.0); // Set the vertices with distance from center as 6.0
        
        System.out.println("Triangle:");
        
        printVertices(triangle);

        Circle circle = new Circle();
        
        circle.setVertices(4.0); // Set the vertices with radius as 4.0
        
        System.out.println("Circle:");
        
        printVertices(circle);
        
    }

    public static void printVertices(Shape shape) {
    	
        int[] can_x = shape.getX();
        
        int[] can_y = shape.getY();

        for (int a = 0; a < can_x.length; a++) {
        	
            System.out.println("Vertices " + (a + 1) + ": (" + can_x[a] + ", " + can_y[a] + ")");
            
        }
        
        System.out.println();
        
    }
}