public class TriangleTester {
	
    public static void main(String[] args) {
    	
        Triangle triangle = new Triangle();
        
        triangle.setVertices(6.0); // Set the vertices with distance from center as 6.0

        // Retrieve the canvas coordinates of the triangle's vertices
        int[] can_x = triangle.getX();
        
        int[] can_y = triangle.getY();

        // Print the canvas coordinates of the triangle's vertices
        for (int a = 0; a < can_x.length; a++) {
        	
            System.out.println("Vertices " + (a + 1) + ": (" + can_x[a] + ", " + can_y[a] + ")");
            
        }
        
    }
    
}