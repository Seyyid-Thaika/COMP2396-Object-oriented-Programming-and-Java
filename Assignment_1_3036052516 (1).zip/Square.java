/**
 * 
 * The Square class represents a square shape that is a subclass of the superclass Shape.
 * It inherits the properties and methods from the Shape class and provides
 * specific implementation for setting the vertices of the square.
 * 
 * @author Seyyid Thaika
 * 
 */

public class Square extends Shape {

    /**
     * 
     * Sets the vertices of the square based on given parameters.
     * The vertices are defined in the local coordinate system 
     * relative to the center of the square.
     *
     * @param d value of 'd' determines the size
     *          of the square and is used to calculate its vertices' coordinates.
     *          
     */
	
    public void setVertices(double d) {
    	
        xLocal = new double[] { d, d, -d, -d };
        
        yLocal = new double[] { d, -d, -d, d };
        
    }
    
}
